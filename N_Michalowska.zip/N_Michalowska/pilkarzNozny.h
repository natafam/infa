#ifndef PILKARZNOZNY_H
#define PILKARZNOZNY_H
#include <string>
#include "pilkarz.h"

using namespace std;

class PilkarzNozny : public Pilkarz {
public:
  PilkarzNozny(string imie_, string nazwisko_, string dataUrodzenia_, string pozycja_, string klub_);
  void StrzelGola();
};

#endif

