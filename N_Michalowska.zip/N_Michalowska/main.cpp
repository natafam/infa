#include <iostream>
#include <locale.h>
#include "pilkarzReczny.h"
#include "pilkarzNozny.h"
#include "student.h"

using namespace std;

int main() {
	setlocale(LC_CTYPE, "Polish");
	
	cout << "Dziedziczenie wielokrotne w C++\n" << "Kod wykona�a Natalia Micha�owska z kl. 3A, gr. 1.\n" << endl;
	
    PilkarzNozny pilkarz_nozny = PilkarzNozny("Robert", "Lewandowski", "21-08-1988", "Napastnik", "Bayern Munich");
    PilkarzReczny pilkarz_reczny = PilkarzReczny("Szymon", "Wieczorek", "07-03-2005", "Rozgrywaj�cy", "HC Husaria Lubliniec");
    Student student = Student("Jan", "Nowak", "16-04-2002", 1, 13, 1234);
    Osoba osoba = Osoba("Natalia", "Micha�owska", "29-10-2006");

    pilkarz_nozny.WypiszInfo();
    cout << "\n" << endl;

    pilkarz_nozny.StrzelGola();
    cout << "\n";
    pilkarz_nozny.WypiszInfo();
    cout << "\n" << endl;


    pilkarz_reczny.WypiszInfo();
    cout << "\n" << endl;

    pilkarz_reczny.StrzelGola();
    cout << "\n";
    pilkarz_reczny.WypiszInfo();
    cout << "\n" << endl;
    

    student.WypiszInfo();
    cout << "\n" << endl;

    osoba.WypiszInfo();
    cout << "\n" << endl;

    cout << "Wszystkie informacje zosta�y pomy�lnie wy�wietlone." << endl;

    return 0;
};

