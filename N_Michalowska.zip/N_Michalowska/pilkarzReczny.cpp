#include <iostream>
#include "pilkarzReczny.h"

using namespace std;

PilkarzReczny::PilkarzReczny(string imie_, string nazwisko_, string dataUrodzenia_, string pozycja_, string klub_) 
    : Pilkarz(imie_, nazwisko_, dataUrodzenia_, pozycja_, klub_) {
};

void PilkarzReczny::StrzelGola() {
    Pilkarz::StrzelGola();
    cout << "R�czny strzeli�!" << endl;
};

