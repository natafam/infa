#ifndef OSOBA_H
#define OSOBA_H
#include <string>

using namespace std;

class Osoba {
    protected:
        string imie;
        string nazwisko;
        string dataUrodzenia;

    public:
        Osoba(string imie_, string nazwisko_, string dataUrodzenia_);
        void WypiszInfo();
};

#endif

