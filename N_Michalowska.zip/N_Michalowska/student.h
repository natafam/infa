#ifndef STUDENT_H
#define STUDENT_H
#include "osoba.h"

using namespace std;

class Student : public Osoba {
    private:
        int rok;
        int grupa;
        int nrIndeksu;

    public:
        Student(string imie_, string nazwisko_, string dataUrodzenia_, int rok_, int grupa_, int nrIndeksu_);
        void WypiszInfo();
};

#endif

