#include <iostream>
#include "pilkarz.h"

using namespace std;

Pilkarz::Pilkarz(string imie_, string nazwisko_, string dataUrodzenia_, string pozycja_, string klub_) 
    : Osoba(imie_, nazwisko_, dataUrodzenia_) {
        pozycja = pozycja_;
        klub = klub_;
        liczbaGoli = 0;
};

void Pilkarz::WypiszInfo() {
    cout << "Imie: " << imie << "\nNazwisko: " << nazwisko << "\nData urodzenia: " << dataUrodzenia << "\nPozycja: " << pozycja << "\nKlub: " << klub << "\nLiczba goli: " << liczbaGoli << endl;
};

void Pilkarz::StrzelGola() {
    liczbaGoli++;
};

