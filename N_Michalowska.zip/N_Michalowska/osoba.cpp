#include <iostream>
#include "osoba.h"

using namespace std;

Osoba::Osoba(string imie_, string nazwisko_, string dataUrodzenia_) {
    nazwisko = nazwisko_;
    imie = imie_;
    dataUrodzenia = dataUrodzenia_;
};

void Osoba::WypiszInfo() {
    cout << "Imie: " << imie << "\nNazwisko: " << nazwisko << "\nData urodzenia: " << dataUrodzenia << endl;
};

