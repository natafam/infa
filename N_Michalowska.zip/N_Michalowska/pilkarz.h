#ifndef PILKARZ_H
#define PILKARZ_H
#include <string>
#include "osoba.h"

using namespace std;

class Pilkarz : public Osoba {
    protected:
        string pozycja;
        string klub;
        int liczbaGoli;

    public:
        Pilkarz(string imie_, string nazwisko_, string dataUrodzenia_, string pozycja_, string klub_);
        void WypiszInfo();
        void StrzelGola();
};

#endif

