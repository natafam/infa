#include <iostream>
#include "pilkarzNozny.h"

using namespace std;

PilkarzNozny::PilkarzNozny(string imie_, string nazwisko_, string dataUrodzenia_, string pozycja_, string klub_) 
    : Pilkarz(imie_, nazwisko_, dataUrodzenia_, pozycja_, klub_) {
};

void PilkarzNozny::StrzelGola() {
    Pilkarz::StrzelGola();
    cout << "No�ny strzeli�!" << endl;
};

