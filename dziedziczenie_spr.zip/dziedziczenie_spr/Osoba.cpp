#include "Osoba.h"
#include <iostream>
using std::cout, std::endl;


Osoba::Osoba(string imie_, string nazwisko_, string dataUrodzenia_) {
    nazwisko = nazwisko_;
    imie = imie_;
    dataUrodzenia = dataUrodzenia_;
}

void Osoba::WypiszInfo() {
    cout << imie << " " << nazwisko << " " << dataUrodzenia << endl;
}