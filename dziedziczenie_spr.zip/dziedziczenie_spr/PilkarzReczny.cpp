#include "PilkarzReczny.h"
#include <iostream>
using std::cout, std::endl;

PilkarzReczny::PilkarzReczny(string imie_, string nazwisko_, string dataUrodzenia_, string pozycja_, string klub_) 
  : Pilkarz(imie_, nazwisko_, dataUrodzenia_, pozycja_, klub_) {
}


void PilkarzReczny::StrzelGola() {
    Pilkarz::StrzelGola();
    cout << "Reczny strzelil" << endl;
}