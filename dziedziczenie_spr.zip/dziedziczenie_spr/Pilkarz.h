#ifndef PILKARZ_H
#define PILKARZ_H

#include "Osoba.h"
#include <string>
using std::string;

class Pilkarz : public Osoba {
protected:
  string pozycja;
  string klub;
  int liczbaGoli;

public:
  Pilkarz(string imie_, string nazwisko_, string dataUrodzenia_, string pozycja_, string klub_);
  void WypiszInfo();
  void StrzelGola();
};

#endif