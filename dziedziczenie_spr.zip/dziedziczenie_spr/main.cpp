#include <iostream>
#include "PilkarzReczny.h"
#include "PilkarzNozny.h"
using namespace std;

int main() {
    PilkarzNozny nozny = PilkarzNozny("Jacek", "Jaworek", "01.01.1960", "Chowajacy", "Sao Paulo");
    nozny.StrzelGola();
    nozny.WypiszInfo();
    return 0;
}