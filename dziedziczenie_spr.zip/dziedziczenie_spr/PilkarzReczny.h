#ifndef PILKARZRECZNY_H
#define PILKARZRECZNY_H

#include "Pilkarz.h"

class PilkarzReczny : public Pilkarz {
public:
  PilkarzReczny(string imie_, string nazwisko_, string dataUrodzenia_, string pozycja_, string klub_);
  void StrzelGola();
};

#endif