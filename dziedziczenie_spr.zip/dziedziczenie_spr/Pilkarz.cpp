#include "Pilkarz.h"
#include <iostream>
using std::cout, std::endl;
  

Pilkarz::Pilkarz(string imie_, string nazwisko_, string dataUrodzenia_, string pozycja_, string klub_) 
  : Osoba(imie_, nazwisko_, dataUrodzenia_) {
   pozycja = pozycja_;
   klub = klub_;
}

void Pilkarz::WypiszInfo() {
    cout << imie << " " << nazwisko << " " << dataUrodzenia << " " << pozycja << " " << klub << endl;
}
void Pilkarz::StrzelGola() {
    liczbaGoli++;
}