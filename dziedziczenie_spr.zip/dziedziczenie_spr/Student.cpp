#include <iostream>
#include "Student.h"
using std::cout, std::endl;

Student::Student(string imie_, string nazwisko_, string dataUrodzenia_, int rok_, int grupa_, int nrIndeksu_) 
   : Osoba(imie_, nazwisko_, dataUrodzenia_) {
   rok = rok_;
   grupa = grupa_;
   nrIndeksu = nrIndeksu_;
}

void Student:: WypiszInfo() {
    cout << imie << " " << nazwisko << " " << dataUrodzenia << " " << rok << " " << grupa << " " << nrIndeksu << " " << endl;
}